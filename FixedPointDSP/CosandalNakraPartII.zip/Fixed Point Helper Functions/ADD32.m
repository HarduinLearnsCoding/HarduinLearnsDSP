function [result] = ADD32(input1,input2)
result=int64(int32(input1)+int32(input2));
end


function [outputArg1,outputArg2] = FixedFilter(inputArg1,inputArg2)


end


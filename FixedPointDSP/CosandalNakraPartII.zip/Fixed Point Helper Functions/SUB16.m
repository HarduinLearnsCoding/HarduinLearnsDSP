function [result] = SUB16(input1,input2)
result=int32(int16(input1)-int16(input2));
end

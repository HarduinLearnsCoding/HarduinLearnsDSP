function [out] = mySqr(vec)
out=conj(vec).*vec;
end


x=int16(10);
y=int16(9);
result=MUL16(x,y);
disp(class(result));

disp(SHIFT(x,1));